function  output = Sigmoid ( x ) 
    output = 1 ./ ( 1 + exp(-x)) ;
end