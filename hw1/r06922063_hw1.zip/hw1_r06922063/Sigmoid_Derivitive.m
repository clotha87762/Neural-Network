function output = Sigmoid_Derivitive( x )
    % return the derivitve sigmoid of x
    output = x .*  (1 - x);
end

